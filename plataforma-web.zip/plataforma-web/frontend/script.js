document.getElementById("registerForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const errorMessage = document.getElementById("error-message");

    if (password !== confirmPassword) {
        errorMessage.textContent = "As senhas não coincidem.";
        return;
    }

    if (password.length < 6) {
        errorMessage.textContent = "A senha deve ter pelo menos 6 caracteres.";
        return;
    }

    const userData = { name, email, password };

    fetch("http://localhost:3000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData),
    })
    .then((response) => {
        if (!response.ok) throw new Error("Erro ao cadastrar usuário.");
        alert("Usuário cadastrado com sucesso!");
    })
    .catch((error) => {
        console.error(error);
        alert("Ocorreu um erro.");
    });
});
